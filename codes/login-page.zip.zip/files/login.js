/* ===== 1) العناصر ===== */
const form      = document.getElementById('loginForm');
const email     = document.getElementById('email');
const password  = document.getElementById('password');
const emailErr  = document.getElementById('emailError');
const passErr   = document.getElementById('passError');
const toggleBtn = document.getElementById('toggle');
const remember  = document.getElementById('remember');
const submitBtn = document.getElementById('submitBtn');
const toast     = document.getElementById('toast');

/* ===== 2) إظهار وإخفاء كلمة المرور ===== */
toggleBtn.addEventListener('click', () => {
  const hidden = password.type === 'password';
  password.type = hidden ? 'text' : 'password';
  toggleBtn.textContent = hidden ? '🙈' : '👁️';
});

/* ===== 3) التحقق من الحقول ===== */
function setError(input, errEl, message) {
  input.closest('.field').classList.toggle('invalid', Boolean(message));
  errEl.textContent = message;
  return !message;            // true إذا ما في خطأ
}

function checkEmail() {
  const v = email.value.trim();
  let msg = '';
  if (!v) msg = 'اكتب بريدك الإلكتروني';
  else if (!/^\S+@\S+\.\S+$/.test(v)) msg = 'البريد الإلكتروني غير صحيح';
  return setError(email, emailErr, msg);
}

function checkPassword() {
  const v = password.value;
  let msg = '';
  if (!v) msg = 'اكتب كلمة المرور';
  else if (v.length < 6) msg = 'كلمة المرور لازم تكون 6 أحرف على الأقل';
  return setError(password, passErr, msg);
}

email.addEventListener('blur', checkEmail);
password.addEventListener('blur', checkPassword);

/* ===== 4) تذكّرني (يحفظ البريد فقط) ===== */
try {
  const saved = localStorage.getItem('remembered-email');
  if (saved) { email.value = saved; remember.checked = true; }
} catch (e) {}

/* ===== 5) إرسال النموذج ===== */
form.addEventListener('submit', (e) => {
  e.preventDefault();

  const okEmail = checkEmail();
  const okPass  = checkPassword();
  if (!okEmail || !okPass) return;

  try {
    if (remember.checked) localStorage.setItem('remembered-email', email.value.trim());
    else localStorage.removeItem('remembered-email');
  } catch (err) {}

  // محاكاة تحميل (هون بتربط مع السيرفر الحقيقي)
  submitBtn.disabled = true;
  submitBtn.textContent = 'جاري الدخول...';

  setTimeout(() => {
    submitBtn.disabled = false;
    submitBtn.textContent = 'تسجيل الدخول';
    showToast('تم تسجيل الدخول بنجاح ✅');
  }, 1200);
});

/* ===== 6) رسالة النجاح ===== */
function showToast(text) {
  toast.textContent = text;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2600);
}
